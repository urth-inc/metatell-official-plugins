"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkcustom_overlay_template"] = self["webpackChunkcustom_overlay_template"] || []).push([["src_bootstrap_tsx"],{

/***/ "./src/App.tsx":
/*!*********************!*\
  !*** ./src/App.tsx ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"webpack/sharing/consume/default/react/react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_CustomOverlay__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/CustomOverlay */ \"./src/components/CustomOverlay/index.ts\");\n/* harmony import */ var _App_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./App.module.scss */ \"./src/App.module.scss\");\n\n\n\nvar App = function App() {\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"div\", {\n    className: _App_module_scss__WEBPACK_IMPORTED_MODULE_2__.appContainer\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"h2\", {\n    className: _App_module_scss__WEBPACK_IMPORTED_MODULE_2__.appHeadingContainer\n  }, \"CustomOverlay Component\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_CustomOverlay__WEBPACK_IMPORTED_MODULE_1__.CustomOverlay, null));\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (App);\n\n//# sourceURL=webpack://custom-overlay-template/./src/App.tsx?");

/***/ }),

/***/ "./src/bootstrap.tsx":
/*!***************************!*\
  !*** ./src/bootstrap.tsx ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"webpack/sharing/consume/default/react/react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_dom_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom/client */ \"./node_modules/react-dom/client.js\");\n/* harmony import */ var _App__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./App */ \"./src/App.tsx\");\n\n\n\nvar remoteElement = document.getElementById(\"root\");\nvar root = (0,react_dom_client__WEBPACK_IMPORTED_MODULE_1__.createRoot)(remoteElement);\nroot.render( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().StrictMode), null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_App__WEBPACK_IMPORTED_MODULE_2__[\"default\"], null)));\n\n//# sourceURL=webpack://custom-overlay-template/./src/bootstrap.tsx?");

/***/ }),

/***/ "./src/components/CustomOverlay/CustomOverlay.tsx":
/*!********************************************************!*\
  !*** ./src/components/CustomOverlay/CustomOverlay.tsx ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   CustomOverlay: () => (/* binding */ CustomOverlay)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"webpack/sharing/consume/default/react/react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _CustomOverlay_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CustomOverlay.module.scss */ \"./src/components/CustomOverlay/CustomOverlay.module.scss\");\n\n\nvar CustomOverlay = function CustomOverlay() {\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"div\", {\n    className: _CustomOverlay_module_scss__WEBPACK_IMPORTED_MODULE_1__.customOverlayContainer\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"div\", {\n    className: _CustomOverlay_module_scss__WEBPACK_IMPORTED_MODULE_1__.sampleOverlay1\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"div\", null, \"Sample Overlay1\")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"div\", {\n    className: _CustomOverlay_module_scss__WEBPACK_IMPORTED_MODULE_1__.overlayWrapper\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"div\", {\n    className: _CustomOverlay_module_scss__WEBPACK_IMPORTED_MODULE_1__.sampleOverlay2\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"div\", null, \"Sample Overlay2\")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"div\", {\n    className: _CustomOverlay_module_scss__WEBPACK_IMPORTED_MODULE_1__.sampleOverlay3\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"div\", null, \"Sample Overlay3\"))));\n};\n\n//# sourceURL=webpack://custom-overlay-template/./src/components/CustomOverlay/CustomOverlay.tsx?");

/***/ }),

/***/ "./src/components/CustomOverlay/index.ts":
/*!***********************************************!*\
  !*** ./src/components/CustomOverlay/index.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   CustomOverlay: () => (/* reexport safe */ _CustomOverlay__WEBPACK_IMPORTED_MODULE_0__.CustomOverlay)\n/* harmony export */ });\n/* harmony import */ var _CustomOverlay__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CustomOverlay */ \"./src/components/CustomOverlay/CustomOverlay.tsx\");\n\n\n//# sourceURL=webpack://custom-overlay-template/./src/components/CustomOverlay/index.ts?");

/***/ }),

/***/ "./src/App.module.scss":
/*!*****************************!*\
  !*** ./src/App.module.scss ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"app-container\": () => (/* binding */ _1),\n/* harmony export */   \"app-heading-container\": () => (/* binding */ _2),\n/* harmony export */   appContainer: () => (/* binding */ _3),\n/* harmony export */   appHeadingContainer: () => (/* binding */ _4)\n/* harmony export */ });\n// extracted by mini-css-extract-plugin\nvar _1 = \"App-module__app-container__hnrRj\";\nvar _2 = \"App-module__app-heading-container__gq_xC\";\nvar _3 = \"App-module__app-container__hnrRj\";\nvar _4 = \"App-module__app-heading-container__gq_xC\";\n\n\n\n//# sourceURL=webpack://custom-overlay-template/./src/App.module.scss?");

/***/ }),

/***/ "./src/components/CustomOverlay/CustomOverlay.module.scss":
/*!****************************************************************!*\
  !*** ./src/components/CustomOverlay/CustomOverlay.module.scss ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"custom-overlay-container\": () => (/* binding */ _1),\n/* harmony export */   customOverlayContainer: () => (/* binding */ _2),\n/* harmony export */   \"overlay-wrapper\": () => (/* binding */ _3),\n/* harmony export */   overlayWrapper: () => (/* binding */ _4),\n/* harmony export */   \"sample-overlay1\": () => (/* binding */ _5),\n/* harmony export */   \"sample-overlay2\": () => (/* binding */ _6),\n/* harmony export */   \"sample-overlay3\": () => (/* binding */ _7),\n/* harmony export */   sampleOverlay1: () => (/* binding */ _8),\n/* harmony export */   sampleOverlay2: () => (/* binding */ _9),\n/* harmony export */   sampleOverlay3: () => (/* binding */ _a)\n/* harmony export */ });\n// extracted by mini-css-extract-plugin\nvar _1 = \"CustomOverlay-module__custom-overlay-container__sBThk\";\nvar _2 = \"CustomOverlay-module__custom-overlay-container__sBThk\";\nvar _3 = \"CustomOverlay-module__overlay-wrapper__g3agX\";\nvar _4 = \"CustomOverlay-module__overlay-wrapper__g3agX\";\nvar _5 = \"CustomOverlay-module__sample-overlay1__JcaXz\";\nvar _6 = \"CustomOverlay-module__sample-overlay2__Wmhy2\";\nvar _7 = \"CustomOverlay-module__sample-overlay3__LCy5l\";\nvar _8 = \"CustomOverlay-module__sample-overlay1__JcaXz\";\nvar _9 = \"CustomOverlay-module__sample-overlay2__Wmhy2\";\nvar _a = \"CustomOverlay-module__sample-overlay3__LCy5l\";\n\n\n\n//# sourceURL=webpack://custom-overlay-template/./src/components/CustomOverlay/CustomOverlay.module.scss?");

/***/ }),

/***/ "./node_modules/react-dom/client.js":
/*!******************************************!*\
  !*** ./node_modules/react-dom/client.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nvar m = __webpack_require__(/*! react-dom */ \"webpack/sharing/consume/default/react-dom/react-dom\");\nif (false) {} else {\n  var i = m.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;\n  exports.createRoot = function(c, o) {\n    i.usingClientEntryPoint = true;\n    try {\n      return m.createRoot(c, o);\n    } finally {\n      i.usingClientEntryPoint = false;\n    }\n  };\n  exports.hydrateRoot = function(c, h, o) {\n    i.usingClientEntryPoint = true;\n    try {\n      return m.hydrateRoot(c, h, o);\n    } finally {\n      i.usingClientEntryPoint = false;\n    }\n  };\n}\n\n\n//# sourceURL=webpack://custom-overlay-template/./node_modules/react-dom/client.js?");

/***/ })

}]);