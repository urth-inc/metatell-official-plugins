export * from './compiled-types/components/CustomOverlay/index';
export { default } from './compiled-types/components/CustomOverlay/index';