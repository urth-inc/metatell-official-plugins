import React from "react";
interface CustomOverlayProps {
}
export declare const CustomOverlay: React.FC<CustomOverlayProps>;
export {};
